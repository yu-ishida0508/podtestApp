//
//  main.m
//  YBPulseButton
//
//  Created by Yahya on 05/04/17.
//  Copyright © 2017 yahya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
